#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 index.src.html + assets/ 打包成单文件 index.html（图片全部内联为 data URI）。
产物只含一个 index.html，无任何外部依赖即可访问。

用法：
    python3 build.py                                   # 不填域名，og:image 退化为相对路径
    python3 build.py --domain https://xxx.github.io/xxx/   # 推荐：一并替换全部占位域名
"""

import argparse
import base64
import os

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, "index.src.html")
OUT = os.path.join(BASE, "index.html")

MIME = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".svg": "image/svg+xml", ".ico": "image/x-icon", ".webp": "image/webp",
}

PLACEHOLDER = "https://example.com/"


def data_uri(rel):
    path = os.path.join(BASE, rel)
    ext = os.path.splitext(path)[1].lower()
    mime = MIME.get(ext, "application/octet-stream")
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return "data:%s;base64,%s" % (mime, b64)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--domain", default=None,
                    help="正式站点地址，结尾带斜杠，如 https://user.github.io/repo/")
    args = ap.parse_args()

    domain = args.domain
    if domain and not domain.endswith("/"):
        domain += "/"

    with open(SRC, encoding="utf-8") as f:
        html = f.read()

    # 0) 单文件版头部说明（源版用 BUILD:BANNER 占位）
    banner = """<!--
  单文件版：图片已全部内联为 data URI，只需把这一个 index.html 传到 GitHub Pages 即可访问。
  ⚠️ 本文件由 build.py 自动生成，请勿直接编辑 —— 请改 index.src.html 后重新运行 `python3 build.py`。

  同目录还需上传（二选一，用于微信 / QQ 分享缩略图，data URI 抓取器读不到）：
      share-square.jpg   800×800 正方形 ← 默认，微信会话小图不被裁切
      og-cover.jpg      1200×630 横图  ← 若换成这张，记得同步改 og:image 的宽高
-->"""
    html = html.replace("<!-- BUILD:BANNER -->", banner)

    # 1) 首屏背景（CSS background，含 body 末尾的后置样式块）
    html = html.replace(
        "url('assets/hero-bg.jpg')",
        "url('%s')" % data_uri("assets/hero-bg.jpg"))

    # 2) 两个 <img>
    for rel in ("assets/lawyer-photo.jpg", "assets/wechat-qr.png"):
        html = html.replace('src="%s"' % rel, 'src="%s"' % data_uri(rel))

    # 3) favicon
    html = html.replace(
        'href="assets/favicon.svg"', 'href="%s"' % data_uri("assets/favicon.svg"))
    html = html.replace(
        'href="assets/favicon.ico"', 'href="%s"' % data_uri("assets/favicon.ico"))

    # 4) 单文件形态下 preload 已无意义（资源已在 HTML 内），移除以免重复下载
    html = html.replace('<link rel="preload" as="image" href="assets/hero-bg.jpg">\n', "")

    # 5) 域名 + 分享缩略图
    #    社交平台抓取器读不到 data URI，缩略图必须是仓库里的真实文件（相对或绝对均可）
    share = ("https://example.com/share-square.jpg", "share-square.jpg")
    if domain:
        html = html.replace(PLACEHOLDER, domain)
    else:
        html = html.replace(share[0], share[1])

    with open(OUT, "w", encoding="utf-8") as f:
        f.write(html)

    size = os.path.getsize(OUT)
    print("生成 %s（%.0f KB）" % (OUT, size / 1024))

    print("og:image →", _meta(html, "og:image"))
    print("canonical →", _attr(html, 'rel="canonical"'))
    left = html.count(PLACEHOLDER)
    if left:
        print("⚠️ 仍有 %d 处占位域名未替换，重新运行：python3 build.py --domain 你的地址/" % left)
    else:
        print("占位域名已全部替换")

    rest = [l.strip()[:80] for l in html.splitlines()
            if "assets/" in l and "favicon" not in l]
    if rest:
        print("剩余 assets/ 引用（应为源版说明文字）：%d 处" % len(rest))


def _meta(html, prop):
    import re
    m = re.search(r'property="%s" content="([^"]+)"' % prop, html)
    return m.group(1) if m else "(未找到)"


def _attr(html, key):
    import re
    m = re.search(r'<link %s href="([^"]+)"' % re.escape(key), html)
    return m.group(1) if m else "(未找到)"


if __name__ == "__main__":
    main()
